import React from 'react'

function NewComponent(props) {
  return (
    <div>
      <h1>Hello Good Morning{props.name}</h1>
    </div>
  )
}
export default NewComponent
