import React, { Component } from 'react'

export default class ComponentClass extends Component {
    constructor(){
        super();
        this.state = {
            count : 0
        }

    }
    incrementCount = () => {
        this.setState({ count: this.state.count + 1 });
    };
    decrementCount = () => {
        this.setState({ count: this.state.count - 1 });
    };
    multiplication = () => {
        this.setState({ count: this.state.count * 5 });
    };
    division = () => {
        this.setState({ count: this.state.count / 2 });
    };
    
  render() {
    return (
      <div>
            <h1>{this.state.count}</h1>
            <button onClick={this.incrementCount}>increment</button>
            <button onClick={this.decrementCount}>decrement</button>
            <button onClick={this.multiplication}>multiplication</button>
            <button onClick={this.division}>division</button>
      </div>
    )
  }
}
